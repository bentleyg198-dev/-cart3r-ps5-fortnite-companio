# CART3R PS5 Fortnite AI Companion

A responsive, static website for off-game Fortnite controller practice. The default profile is **PS5 / Tracking / 75% intensity**.

## What it does
- Tracking practice arena with a moving target and tap counter
- Adjustable intensity and drill duration
- Smooth tracking, reaction tracking, and precision follow modes
- Coaching tips and mobile share controls
- Responsive layout for phones and desktops
- No account, database, API key, or backend required

## Important limitations
This is an independent practice companion. It does **not** connect to a PS5 or Fortnite, read gameplay, modify the game, provide in-game aim assist, unlock cosmetics, or bypass anti-cheat. It is intended for off-game practice and coaching.

## Run locally
1. Download and unzip the project.
2. Open `index.html` in a modern browser.
3. To test the share button, serve it from a local web server rather than opening the file directly. For example, with Python installed, run `python -m http.server 8000` in the project folder and visit `http://localhost:8000`.

## Deploy publicly on Render
1. Create a GitHub repository named `cart3r-ps5-fortnite-companion`.
2. Upload `index.html`, `styles.css`, `app.js`, and `render.yaml` (README optional) to the repository root.
3. Sign in to [Render](https://render.com/).
4. Choose **New +** → **Static Site** and connect your GitHub repository.
5. Render should detect `render.yaml`. If configuring manually:
   - Build command: leave blank
   - Publish directory: `.`
6. Click **Create Static Site** and wait for deployment.
7. Open the `https://<your-service-name>.onrender.com` URL shown by Render.
8. Send that public URL to friends in a PlayStation message. Anyone with the link can open the website in a browser on a phone, tablet, or computer.

## Updating the site
Push changes to the connected GitHub branch. Render automatically redeploys the static site.

## Project structure
```text
cart3r-ps5-fortnite-companion/
├── index.html
├── styles.css
├── app.js
├── render.yaml
└── README.md
```

## Privacy
The app has no analytics, login, or server-side data collection. Session score and settings exist only in the current browser page and are not uploaded.
