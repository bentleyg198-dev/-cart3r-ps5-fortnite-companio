(() => {
  const $ = (id) => document.getElementById(id);
  const arena = $("arena"), target = $("target"), startBtn = $("startBtn");
  let running = false, remaining = 30, duration = 30, score = 0, elapsed = 0;
  let tick = null, mover = null, targetX = .5, targetY = .5, lastTip = -1;
  const tips = [
    ["Build smooth control first.","At 75% intensity, aim for steady target contact. Relax your hands, keep your posture comfortable, and take a short break if you feel tension."],
    ["Make small corrections.","Try to anticipate the target's path instead of chasing every movement. Smooth adjustments are more useful than sudden over-corrections."],
    ["Consistency beats speed.","Repeat short practice sessions and track your own progress. Increase difficulty only when you can stay controlled."],
    ["Reset your grip.","Keep your controller grip comfortable and avoid squeezing too tightly. Take breaks if your hands or wrists become uncomfortable."]
  ];
  function toast(message) { const el=$("toast"); el.textContent=message; el.classList.add("show"); setTimeout(()=>el.classList.remove("show"),2200); }
  function updateTimer(){ $("timer").textContent=`00:${String(remaining).padStart(2,"0")}`; }
  function placeTarget(){
    const pad=28, w=arena.clientWidth, h=arena.clientHeight;
    const intensity=Number($("intensity").value);
    const edge=pad+Math.round((100-intensity)*.45);
    targetX=edge+Math.random()*(w-edge*2); targetY=edge+Math.random()*(h-edge*2);
    target.style.left=`${targetX}px`; target.style.top=`${targetY}px`;
  }
  function moveTarget(){
    const drill=$("drill").value, intensity=Number($("intensity").value);
    const interval=drill==="react"?Math.max(480,1450-intensity*8):drill==="precision"?Math.max(900,2100-intensity*8):Math.max(650,1750-intensity*8);
    clearInterval(mover);
    mover=setInterval(()=>{ if(!running)return; placeTarget(); },interval);
  }
  function stopDrill(message){
    running=false; clearInterval(tick); clearInterval(mover); target.style.display="none";
    $("arenaHint").style.display="grid"; $("arenaHint").textContent=message;
    startBtn.textContent="START AGAIN"; $("drillStatus").textContent=message;
  }
  function startDrill(){
    if(running)return;
    duration=Number($("duration").value); remaining=duration; elapsed=0; score=0;
    $("score").textContent="0"; updateTimer(); $("progressBar").style.width="0%";
    $("arenaHint").style.display="none"; target.style.display="grid";
    $("drillStatus").textContent="Stay with the target."; startBtn.textContent="DRILL RUNNING";
    running=true; placeTarget(); moveTarget();
    tick=setInterval(()=>{
      remaining--; elapsed++;
      updateTimer(); $("progressBar").style.width=`${(elapsed/duration)*100}%`;
      if(remaining<=0){ stopDrill(`Complete! You recorded ${score} target taps.`); toast("Drill complete — nice work!"); }
    },1000);
  }
  target.addEventListener("pointerdown",(event)=>{
    if(!running)return;
    event.preventDefault(); score++; $("score").textContent=String(score);
    if($("soundToggle").checked){
      try{const C=window.AudioContext||window.webkitAudioContext;const ctx=new C();const osc=ctx.createOscillator();const gain=ctx.createGain();osc.connect(gain);gain.connect(ctx.destination);osc.frequency.value=620;gain.gain.value=.035;osc.start();osc.stop(ctx.currentTime+.045);}catch(_){}
    }
    if($("drill").value==="react") placeTarget();
  });
  arena.addEventListener("pointermove",(event)=>{
    const rect=arena.getBoundingClientRect(), cross=$("arenaCross");
    cross.style.display=running?"block":"none"; cross.style.left=`${event.clientX-rect.left}px`;cross.style.top=`${event.clientY-rect.top}px`;
  });
  arena.addEventListener("pointerleave",()=>{$("arenaCross").style.display="none";});
  startBtn.addEventListener("click",startDrill);
  $("resetBtn").addEventListener("click",()=>{stopDrill("Ready when you are.");remaining=Number($("duration").value);score=0;$("score").textContent="0";$("progressBar").style.width="0%";updateTimer();startBtn.textContent="START DRILL";});
  $("duration").addEventListener("change",()=>{if(!running){remaining=Number($("duration").value);updateTimer();}});
  $("intensity").addEventListener("input",e=>{$("intensityValue").textContent=`${e.target.value}%`;});
  $("drill").addEventListener("change",e=>{$("drillName").textContent=e.target.selectedOptions[0].textContent;if(running)moveTarget();});
  $("newTip").addEventListener("click",()=>{let next;do{next=Math.floor(Math.random()*tips.length)}while(next===lastTip&&tips.length>1);lastTip=next;$("coachTitle").textContent=tips[next][0];$("coachText").textContent=tips[next][1];});
  async function share(){
    const data={title:"CART3R PS5 Fortnite Companion",text:"Try this Fortnite controller practice companion:",url:window.location.href};
    try{if(navigator.share)await navigator.share(data);else if(navigator.clipboard?.writeText){await navigator.clipboard.writeText(window.location.href);toast("Website link copied!");}else{prompt("Copy this website link:",window.location.href);}}
    catch(err){if(err.name!=="AbortError")toast("Sharing unavailable. Copy the page URL from your browser.");}
  }
  ["shareTop","shareHero","shareSettings"].forEach(id=>$(id).addEventListener("click",share));
  updateTimer();
})();